package com.example.examwallet.ui

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Toast
import androidx.core.view.isGone
import com.example.examwallet.MainActivity
import com.example.examwallet.databinding.ActivityPinLoginBinding

class PinLoginActivity : AppCompatActivity() {
    companion object{
        const val PIN_VALUE = "Actual PIN"
    }

    lateinit var pinLoginBinding : ActivityPinLoginBinding;
    private lateinit var appPreferences: SharedPreferences;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        pinLoginBinding = ActivityPinLoginBinding.inflate(layoutInflater);
        setContentView(pinLoginBinding.root);
        appPreferences = getSharedPreferences(PIN_VALUE, MODE_PRIVATE);

        if(isFirstStart()) initFirstStart();

        initUI();

    }

    private fun isFirstStart(): Boolean{
        //Log.i("Log-i", "isFirstStart");
        return if(appPreferences.getBoolean("firstStart", true).equals(true)) {
            val editor: SharedPreferences.Editor = appPreferences.edit();
            editor.putBoolean("firstStart", false);
            editor.apply();
            true
        } else{
            //Log.i("Log-i", "Aktuális PIN ${appPreferences.getString("actPIN", "0000")}");
            false
        }
    }

    private fun initFirstStart(){
        //Log.i("Log-i", "initFirstStart");
        val editor: SharedPreferences.Editor = appPreferences.edit();
        editor.putString("actPIN", "7654");
        editor.apply();
        Toast.makeText(this, "Kezdeti PIN: 7654", Toast.LENGTH_LONG).show();
        //Log.i("Log-i", "initFirstStart PIN: ${appPreferences.getString("actPIN", "0000")}");
     }

    private fun initUI(){
        pinLoginBinding.loginButton.setOnClickListener {

            //Log.i("Log-i", "READPIN: ${readPIN()::class}");
            //Log.i("Log-i", "READPIN: ${appPreferences.getString("actPIN","0")!!::class}");

            if(checkPINInput() && readPIN().equals(appPreferences.getString("actPIN","0"))) {
                startActivity(Intent(this, MainActivity::class.java));
                clearPINInput();
            }
            else {
                Toast.makeText(this, "A megadott PIN: ${readPIN()} nem megfelelő!", Toast.LENGTH_SHORT).show();
                clearPINInput();
            }
        }

        pinLoginBinding.shortcutButton.isGone = true;
        /*
        pinLoginBinding.shortcutButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java));
        }
         */

        pinLoginBinding.pin1.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                Log.i("Log-i", "onTextChanged");
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                Log.i("Log-i", "beforeTextChanged");
            }

            override fun afterTextChanged(s: Editable) {
                Log.i("Log-i", "afterTextChanged");
                if(pinLoginBinding.pin1.text.length ==1){
                    pinLoginBinding.pin2.requestFocus();
                }
            }
        })
        pinLoginBinding.pin2.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                Log.i("Log-i", "onTextChanged");
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                Log.i("Log-i", "beforeTextChanged");
            }
            override fun afterTextChanged(s: Editable) {
                Log.i("Log-i", "afterTextChanged");
                if(pinLoginBinding.pin1.text.length ==1){
                    pinLoginBinding.pin3.requestFocus();
                }
            }
        })
        pinLoginBinding.pin3.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                Log.i("Log-i", "onTextChanged");
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                Log.i("Log-i", "beforeTextChanged");
            }
            override fun afterTextChanged(s: Editable) {
                Log.i("Log-i", "afterTextChanged");
                if(pinLoginBinding.pin1.text.length ==1){
                    pinLoginBinding.pin4.requestFocus();
                }
            }
        })
        pinLoginBinding.pin4.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                Log.i("Log-i", "onTextChanged");
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                Log.i("Log-i", "beforeTextChanged");
            }
            override fun afterTextChanged(s: Editable) {
                Log.i("Log-i", "afterTextChanged");
            }
        })
    }

    private fun checkPINInput() : Boolean {
        Log.i("Log-i", "checkPINInput");
        return !(pinLoginBinding.pin1.text.isEmpty()
                || pinLoginBinding.pin2.text.isEmpty()
                || pinLoginBinding.pin3.text.isEmpty()
                || pinLoginBinding.pin4.text.isEmpty())
    }

    private fun readPIN() : String{
        //Log.i("Log-i", "readPIN");
        val pinString = "${pinLoginBinding.pin1.text}${pinLoginBinding.pin2.text}${pinLoginBinding.pin3.text}${pinLoginBinding.pin4.text}";
        //Toast.makeText(this, pinString, Toast.LENGTH_LONG).show();
        //Log.i("Log-i", pinString);
        return pinString;
    }

    private fun clearPINInput(){
        val digits = arrayOf(pinLoginBinding.pin1, pinLoginBinding.pin2, pinLoginBinding.pin3, pinLoginBinding.pin4);
        digits.forEach {
            it.text.clear();
        }
        pinLoginBinding.pin1.requestFocus();
    }
}