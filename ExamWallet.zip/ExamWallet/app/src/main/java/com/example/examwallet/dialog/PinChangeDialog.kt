package com.example.examwallet.dialog

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.examwallet.MainActivity
import com.example.examwallet.databinding.DialogPinChangeBinding

class PinChangeDialog : DialogFragment(){

    private lateinit var newPIN: EditText;

    //Fragment lifecycle elso allapota
    override fun onAttach(context: Context) {
        super.onAttach(context);
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("PIN kód megváltoztatása")

        val rootView = DialogPinChangeBinding.inflate(requireActivity().layoutInflater);

        newPIN = rootView.newPINInput;

        builder.setView(rootView.root);

        builder.setPositiveButton("OK") { dialog, which ->
            //... keep empty
        }
        builder.setNegativeButton("Mégsem") { dialog, which ->
            //... keep empty
        }
        return builder.create()
    }

    //Fragment lifecycle aktivalasi allapota
    override fun onResume() {
        super.onResume()

        val dialog = dialog as AlertDialog //??
        val positiveButton = dialog.getButton(Dialog.BUTTON_POSITIVE) //??

        positiveButton.setOnClickListener {


            if (newPIN.text.length != 4){
                    Toast.makeText(context, "A PIN kódnak 4 karakterből kell állnia!", Toast.LENGTH_SHORT).show()
            } else {
                val appPreferences = (context as MainActivity).getSharedPreferences("Actual PIN", MODE_PRIVATE);
                val editor: SharedPreferences.Editor = appPreferences.edit();
                editor.putString("actPIN", newPIN.text.toString())
                editor.apply();
                Toast.makeText(context, "Az új PIN: ${appPreferences.getString("actPIN", "0")}", Toast.LENGTH_SHORT).show()
                dialog.dismiss();
            }
        }

    }

}

