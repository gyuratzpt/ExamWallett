package com.example.examwallet.recyclerdata

data class WallettItem(
    var income: Boolean,
    var date: String,
    var name: String,
    var amount: Int
    //, var cat: String

)
