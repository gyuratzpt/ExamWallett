package com.example.examwallet.recycleradapter

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isGone
import androidx.recyclerview.widget.RecyclerView
import com.example.examwallet.MainActivity
import com.example.examwallet.database.AppDatabase
import com.example.examwallet.database.DatabaseItem
import com.example.examwallet.databinding.WallettitemBinding
import com.example.examwallet.recyclerdata.WallettItem

class WallettAdapter : RecyclerView.Adapter<WallettAdapter.ViewHolder> {

        var adapterLocalInnerList = mutableListOf<WallettItem>();
        var adapterDatabaseInnerList = mutableListOf<DatabaseItem>();

        val context: Context;
        constructor(context: Context, inputList: List<DatabaseItem>) : super(){
            this.context = context;
            adapterDatabaseInnerList.addAll(inputList);

        }

        inner class ViewHolder(val wallettItemViewBinding: WallettitemBinding): RecyclerView.ViewHolder(wallettItemViewBinding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            //Log.i("Log-i", "onCreateViewHolder");
            return ViewHolder(
                WallettitemBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            //Log.i("Log-i", "onBindViewHolder");
            //var actualItem = adapterLocalInnerList[position];
            val actualItem = adapterDatabaseInnerList[position];


            holder.wallettItemViewBinding.date.text = "(${actualItem.id}) ${actualItem.date}";
            holder.wallettItemViewBinding.name.text = actualItem.name;
            holder.wallettItemViewBinding.amount.text = "${if(!actualItem.income) "-" else ""} ${actualItem.amount}";

            if(actualItem.income){
                holder.wallettItemViewBinding.imageView.setImageResource(com.google.android.material.R.drawable.material_ic_menu_arrow_up_black_24dp);
                holder.wallettItemViewBinding.imageView.setBackgroundColor(Color.GREEN)
            } else {
                holder.wallettItemViewBinding.imageView.setImageResource(com.google.android.material.R.drawable.material_ic_menu_arrow_down_black_24dp)
                holder.wallettItemViewBinding.imageView.setBackgroundColor(Color.RED)
            };

            holder.wallettItemViewBinding.deleteButton.setOnClickListener {
                Log.i("Log-i", "AdapterPosition: ${holder.adapterPosition}, Position: ${position}, ListSize ${adapterDatabaseInnerList.size}");
                Thread{
                    AppDatabase.getInstance(context).DatabaseDAO().deleteElement(actualItem);
                    (context as MainActivity).runOnUiThread{
                        adapterDatabaseInnerList.removeAt(holder.adapterPosition);
                        notifyItemRemoved(holder.adapterPosition);
                        context.setBalance();
                    }
                }.start();


                //printLog();
            }

            holder.wallettItemViewBinding.infoButton.isGone = true;
            /*
            holder.wallettItemViewBinding.infoButton.setOnClickListener {
                Log.i(
                    "Log-i",
                    "AdapterPosition: ${holder.adapterPosition}, LayoutPosition: ${holder.layoutPosition}, Position: ${position}"
                );
            }
             */
        }

        override fun getItemCount(): Int {
            //Log.i("Log-i", "getItemCount");
            //return adapterLocalInnerList.size;
            return adapterDatabaseInnerList.size;
        }


        fun addNewElement(input: DatabaseItem, newID: Long?){
            adapterDatabaseInnerList.add(0, input);
            adapterDatabaseInnerList[adapterDatabaseInnerList.indexOf(input)].id = newID;
            notifyItemInserted(adapterDatabaseInnerList.indexOf(input));
            //printLog();
        }
    /*
    fun addNewElement(input: DatabaseItem, newID: Long?){
        adapterDatabaseInnerList.add(input);
        adapterDatabaseInnerList[adapterDatabaseInnerList.lastIndex].id = newID;
        notifyItemInserted(adapterDatabaseInnerList.lastIndex);
        //printLog();
    }

     */



        fun printLog(){
            Log.i("Log-i", "Lista mérete: ${adapterDatabaseInnerList.size}");
            Log.i("Log-i", "Lista elemei:");
            adapterDatabaseInnerList.forEach {
                Log.i("Log-i", "$it");
            }

        }

}