package com.example.examwallet.database

import androidx.room.*

@Dao
interface DatabaseDAO {
    @Query("SELECT * FROM databaseTable")
    fun getFullDatabaseTable() : List<DatabaseItem>;

    @Query("SELECT * FROM databaseTable WHERE income = :bool")
    fun getFilteredBalance(bool: Boolean) : List<DatabaseItem>;


    @Query("DELETE FROM databaseTable")
    fun deleteEntireDatabaseTable();

    @Insert
    fun insertNewElement(vararg newElements : DatabaseItem);

    @Delete
    fun deleteElement(elementToDelete : DatabaseItem)

    @Update
    fun updateElement(elementToUpdate : DatabaseItem)

}