package com.example.examwallet.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "databaseTable")
data class DatabaseItem(
    @PrimaryKey(autoGenerate = true) var id: Long?,
    @ColumnInfo(name = "income") var income: Boolean,
    @ColumnInfo(name = "date") var date: String,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "amount") var amount: Int
    //,@ColumnInfo(name = "category") var category: Int

)
