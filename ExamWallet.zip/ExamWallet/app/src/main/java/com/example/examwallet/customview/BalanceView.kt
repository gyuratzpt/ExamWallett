package com.example.examwallet.customview

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.example.examwallet.customviewmodell.BalanceModell
import com.example.examwallet.ui.BalanceActivity

class BalanceView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {

    private var backgroundPainter : Paint = Paint();
    private var axisPainter : Paint = Paint();
    private var expensesFiller : Paint = Paint();
    private var incomeFiller : Paint = Paint();

    init{
        /*
        val hsv = FloatArray(3);
        //Hue, Saturation, Value (fenyero)
        Log.i("i-Log", "${hsv[0]} ${hsv[1]} ${hsv[2]}");
        Color.RGBToHSV(23,172,201,hsv);
        Log.i("i-Log", "${hsv[0]} ${hsv[1]} ${hsv[2]}");
        */
        BalanceModell.initBalance((context as BalanceActivity).provideBalanceValues());
        initPainterObjects();

    }

    fun initPainterObjects() {
        backgroundPainter.color = Color.BLACK;
        backgroundPainter.style = Paint.Style.FILL;

        axisPainter.color = Color.WHITE;
        axisPainter.style = Paint.Style.STROKE;
        axisPainter.strokeWidth = 5f;
        axisPainter.textSize = 40F;

        expensesFiller.color = Color.RED;
        expensesFiller.style = Paint.Style.FILL;

        incomeFiller.color = Color.GREEN;
        incomeFiller.style = Paint.Style.FILL;
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas);
        canvas.drawRect(0f,0f, width.toFloat() ,height.toFloat(), backgroundPainter);


        drawBalance(canvas);
        drawAxisSystem(canvas);

        //if(position.x>=0 && position.y>=0) canvas?.drawCircle((position.x).toFloat(),(position.y).toFloat(), 20f, linePainter);
    }

    private fun drawBalance(canvas: Canvas) {

        val onepercentpixels = (((height.toFloat() / 7) * 5) / 100);

        //(context as BalanceActivity).setBalanceTitle("View.W: $width / View.H: $height / Y-Axis.H: ${(height.toFloat() / 7) * 5} / 1%: ${onepercentpixels} / In.H: ${(actBalance[0] / (actBalance[0] + actBalance[1]).toFloat()) * 100 * onepercentpixels}");
        //(context as BalanceActivity).setBalanceHelp("Max: ${actBalance[0] + actBalance[1]} / In: ${actBalance[0]} / Exp: ${actBalance[1]}");
        (context as BalanceActivity).setBalanceTitle("Total Balance");

        //income bar
        canvas.drawRect(
            (width / 7) * 3 - 50.toFloat(),
            //(height/7).toFloat(),
            ((height / 7) * 6) - ((BalanceModell.getIncome() / BalanceModell.getMaxBalance().toFloat()) * 100 * onepercentpixels),
            (width / 7) * 3 + 50.toFloat(),
            ((height / 7) * 6).toFloat(),
            incomeFiller
        );
        canvas.drawText(
            "Income",
            (width / 7) * 3 - 60.toFloat(),
            ((height / 7) * 6) + (height / 15).toFloat(),
            axisPainter
        );

        // expense bar
        canvas.drawRect(
            ((width / 3) * 2) - 50.toFloat(),
            //(height/7).toFloat(),
            ((height / 7) * 6) - ((BalanceModell.getExpenses() / BalanceModell.getMaxBalance().toFloat()) * 100 * onepercentpixels),
            ((width / 3) * 2) + 50.toFloat(),
            ((height / 7) * 6).toFloat(),
            expensesFiller
        );
        canvas.drawText(
            "Expenses",
            ((width / 3) * 2) - 80.toFloat(),
            ((height / 7) * 6) + (height / 15).toFloat(),
            axisPainter
        );
    }

    private fun drawAxisSystem(canvas: Canvas){
        // x-axis
        //canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), linePainter)
        canvas.drawLine(
            (width / 7) * 2.toFloat(),
            (height / 7).toFloat(),
            (width / 7) * 2.toFloat(),
            ((height / 7) * 6).toFloat(),
            axisPainter
        );
        // y-axis
        canvas.drawLine(
            (width / 7) * 2.toFloat(),
            ((height / 7) * 6).toFloat(),
            ((width / 7) * 6).toFloat(),
            ((height / 7) * 6).toFloat(),
            axisPainter
        );



        for (i in 1..5) {
            canvas.drawLine(
                (width / 7) * 2 - 15.toFloat(),
                (height / 7) * i.toFloat(),
                (width / 7) * 2 + 15.toFloat(),
                (height / 7) * i.toFloat(),
                axisPainter
            );
        }

        for (i in 1..5) {
            canvas.drawText(
                "${BalanceModell.getBalanceScale(i-1)}",
                (width / 7).toFloat(),
                ((height / 7) * i) + (height/100).toFloat(),
                axisPainter
            );
        }


        canvas.drawText(
            "0",
            (width / 7) * 2 - 100.toFloat(),
            (height / 7) * 6 + (height / 100).toFloat(),
            axisPainter
        );
    }
}