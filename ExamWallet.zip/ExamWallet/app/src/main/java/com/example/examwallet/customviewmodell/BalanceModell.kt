package com.example.examwallet.customviewmodell


object BalanceModell {
    private var actualBalance = IntArray(3);
    private var balanceScale = IntArray(5);


    fun initBalance(input: IntArray){
        actualBalance = input;

        for (i in 1 .. 5){
        //for (i in 5 downTo 1){
            balanceScale[i-1] = (getMaxBalance()/5)*i;
        }
        balanceScale.reverse();
    }

    fun getMaxBalance(): Int{
        return actualBalance[0] + actualBalance[1];
    }
    fun getIncome(): Int{
        return actualBalance[0];
    }
    fun getExpenses(): Int{
        return actualBalance[1];
    }

    fun getBalanceScale(i: Int): Int{
        return balanceScale[i];
    }

}