package com.example.examwallet

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isGone
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.examwallet.database.AppDatabase
import com.example.examwallet.database.DatabaseItem
import com.example.examwallet.databinding.ActivityMainBinding
import com.example.examwallet.dialog.PinChangeDialog
import com.example.examwallet.recycleradapter.WallettAdapter
import com.example.examwallet.ui.BalanceActivity
import java.time.LocalDate

class MainActivity : AppCompatActivity() {
    private lateinit var mainActivityBinding : ActivityMainBinding;
    private lateinit var recyclerViewAdapter : WallettAdapter;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mainActivityBinding = ActivityMainBinding.inflate(layoutInflater);
        setContentView(mainActivityBinding.root);

        initUI();
        initRecyclerView();

    }

    private fun initUI(){

        mainActivityBinding.inputRouter.isChecked = false;
        mainActivityBinding.inputRouter.text = "Kiadás"
        //mainActivityBinding.inputRouter.setBackgroundColor(Color.RED);

        mainActivityBinding.inputRouter.setOnClickListener {
            if(mainActivityBinding.inputRouter.isChecked){
                mainActivityBinding.inputRouter.text = "Bevétel"
                //mainActivityBinding.inputRouter.setBackgroundColor(Color.GREEN);
            }
            else{
                mainActivityBinding.inputRouter.text = "Kiadás"
                //mainActivityBinding.inputRouter.setBackgroundColor(Color.RED);
            }
        }
        mainActivityBinding.inputButton.setOnClickListener {
            if(mainActivityBinding.inputName.text.isEmpty()) Toast.makeText(this, "Hiányzó név", Toast.LENGTH_LONG).show()
            else if(mainActivityBinding.inputAmount.text.isEmpty()) Toast.makeText(this, "Hiányzó összeg", Toast.LENGTH_LONG).show()
            else {
                newListElementCreated(
                    DatabaseItem(
                        null,
                        mainActivityBinding.inputRouter.isChecked,
                        LocalDate.now().toString(),
                        mainActivityBinding.inputName.text.toString(),
                        mainActivityBinding.inputAmount.text.toString().toInt()
                    )
                )
                mainActivityBinding.inputName.text.clear();
                mainActivityBinding.inputAmount.text.clear();
                mainActivityBinding.inputName.requestFocus();
            }
        }

        mainActivityBinding.clearDataBaseButton.isGone = true;
        mainActivityBinding.fillDataBaseButton.isGone = true;
        mainActivityBinding.getlogButton.isGone = true;

        /*
        mainActivityBinding.getlogButton.setOnClickListener {
            Log.i("Log-i", "");
            Log.i("Log-i", "---===×××GETLOG×××===---");
            Log.i("Log-i", "");
            Thread{
                var actDatabaseList = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFullDatabaseTable();
                runOnUiThread {
                    Log.i("Log-i", "---===×××Database×××===---");
                    Log.i("Log-i", "Size: ${actDatabaseList.size}");
                    actDatabaseList.forEach {
                        Log.i("Log-i", "${it}");
                    }
                    Log.i("Log-i", "---===×××Recyclerview×××===---");
                    Log.i("Log-i", "Size: ${recyclerViewAdapter.adapterDatabaseInnerList.size}");
                    recyclerViewAdapter.adapterDatabaseInnerList.forEach{
                        Log.i("Log-i", "${it}");
                    }
                }
            }.start();
        }
        */
/*
        mainActivityBinding.fillDataBaseButton.setOnClickListener {
            Thread{
                AppDatabase.getInstance(this@MainActivity).DatabaseDAO().insertNewElement(
                    DatabaseItem(null, true,LocalDate.now().toString(),"Fizu",2100),
                    DatabaseItem(null, false,"2021-05-22","Rezsi",450),
                    DatabaseItem(null, false,LocalDate.now().toString(),"Auto",360),
                    DatabaseItem(null, true,"2020-07-29","Kolcson",100),
                    DatabaseItem(null, false,LocalDate.now().toString(),"Bolt",190)
                );
                var actDatabaseList = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFullDatabaseTable();
                runOnUiThread {
                    recyclerViewAdapter.adapterDatabaseInnerList.clear();
                    recyclerViewAdapter.adapterDatabaseInnerList.addAll(actDatabaseList);
                    recyclerViewAdapter.notifyDataSetChanged();
                    setBalance();
                }
            }.start();
        }

 */
        /*
        mainActivityBinding.clearDataBaseButton.setOnClickListener {
            Thread{
                AppDatabase.getInstance(this@MainActivity).DatabaseDAO().deleteEntireDatabaseTable();
                var actDatabaseList = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFullDatabaseTable();
                runOnUiThread {
                    recyclerViewAdapter.adapterDatabaseInnerList.clear();
                    recyclerViewAdapter.notifyDataSetChanged();
                    setBalance();
                }
            }.start();
        }


         */


    }

    private fun initRecyclerView() {
        Thread{
            val databaseElements = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFullDatabaseTable();
            runOnUiThread {
                recyclerViewAdapter = WallettAdapter(this, databaseElements.reversed());
                mainActivityBinding.recyclerview.adapter = recyclerViewAdapter;
                mainActivityBinding.recyclerview.addItemDecoration(
                    DividerItemDecoration(
                    this,
                    LinearLayoutManager.HORIZONTAL));
                setBalance();
            }
        }.start();
    }

    fun setBalance(){
        Thread{
            val incomes = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFilteredBalance(true);
            val expenses = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFilteredBalance(false);
            runOnUiThread {
                var sumIncome = 0;
                incomes.forEach{
                    sumIncome += it.amount;
                }
                var sumExpenses = 0;
                expenses.forEach{
                    sumExpenses += it.amount;
                }

                mainActivityBinding.income.text = sumIncome.toString();
                mainActivityBinding.expenses.text = sumExpenses.toString();
                mainActivityBinding.balance.text = " = ${sumIncome-sumExpenses}";

            }
        }.start();
    }

    private fun newListElementCreated(listItem: DatabaseItem) {
        Thread{
            AppDatabase.getInstance(this@MainActivity).DatabaseDAO().insertNewElement(listItem);
            val actDatabaseList = AppDatabase.getInstance(this@MainActivity).DatabaseDAO().getFullDatabaseTable();
            runOnUiThread {
                val newID = actDatabaseList[actDatabaseList.size-1].id;
                recyclerViewAdapter.addNewElement(listItem, newID);
                setBalance();
            }
        }.start();
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_balance -> {
                //Toast.makeText(this, "changepin", Toast.LENGTH_LONG).show();
                startActivity(Intent(this, BalanceActivity::class.java)
                    .putExtra("income", mainActivityBinding.income.text.toString().toInt())
                    .putExtra("expenses", mainActivityBinding.expenses.text.toString().toInt())
                );
            }
            R.id.menu_changepin -> {
                //Toast.makeText(this, "changepin", Toast.LENGTH_LONG).show();
                PinChangeDialog().show(supportFragmentManager,"PIN megváltoztatása");

            }
            R.id.menu_deletedatabase -> {
                //Toast.makeText(this, "deletedatabase", Toast.LENGTH_LONG).show();

                val dialogBuilder = AlertDialog.Builder(this)

                // set message of alert dialog
                dialogBuilder.setMessage("Valóban törölni akarja az adatbazis tartalmát?")
                    // if the dialog is cancelable
                    .setCancelable(false)

                    // positive button text and action
                    .setPositiveButton("Törlés", DialogInterface.OnClickListener {
                            dialog, id ->
                        //Toast.makeText(this, "deletedatabase run", Toast.LENGTH_LONG).show();

                        Thread{
                            AppDatabase.getInstance(this@MainActivity).DatabaseDAO().deleteEntireDatabaseTable();
                            runOnUiThread {
                                recyclerViewAdapter.adapterDatabaseInnerList.clear();
                                recyclerViewAdapter.notifyDataSetChanged();
                                setBalance();
                            }
                        }.start();
                    })

                    // negative button text and action
                    .setNegativeButton("Mégsem", DialogInterface.OnClickListener {
                        dialog, id ->
                        //Toast.makeText(this, "deletedatabase cancel", Toast.LENGTH_LONG).show();
                        dialog.cancel();
                    })

                // create dialog box
                val alert = dialogBuilder.create()
                // set title for alert dialog box
                alert.setTitle("FIGYELEM!")
                // show alert dialog
                alert.show()

            }
            R.id.menu_exit -> {
                //Toast.makeText(this, "exit", Toast.LENGTH_LONG).show();
                finish();
            }
        }

        return true
    }


}