package com.example.examwallet.ui

import android.graphics.Color
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.View.OnAttachStateChangeListener
import android.view.ViewAnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isGone
import com.example.examwallet.databinding.ActivityBalanceBinding
import kotlin.math.hypot


class BalanceActivity : AppCompatActivity() {
    private lateinit var balanceActivityBinding : ActivityBalanceBinding;
    private lateinit var values : IntArray;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        values = IntArray(3);
        values[0] = intent.getIntExtra("income",0);
        values[1] = intent.getIntExtra("expenses",0);
        values[2] = values[0]-values[1];

        balanceActivityBinding = ActivityBalanceBinding.inflate(layoutInflater);
        setContentView(balanceActivityBinding.root);
        balanceActivityBinding.balanceHelp.isGone = true;

        //tv átadása hogyan? v.text nem jó
        //setSpannableTextView(balanceActivityBinding.income, "Income: ${values[0]}", Color.GREEN, 7);
        balanceActivityBinding.income.text = setSpannableTextView("Income: ${values[0]}", Color.GREEN, 7);
        balanceActivityBinding.expenses.text = setSpannableTextView("Expenses: ${values[1]}", Color.RED, 8);
        balanceActivityBinding.balance.text = setSpannableTextView("Balance: ${values[2]}", if(values[2] > 0 ) Color.GREEN else Color.RED, if(values[2] > 0 ) 7 else 8);


        //revealView();

    }

    fun setSpannableTextView(str: String, col: Int, range :Int): Spannable{
        val s = SpannableString(str);
        s.setSpan(ForegroundColorSpan(col),
            0, // start
            range, // end
            Spannable.SPAN_INCLUSIVE_EXCLUSIVE
        );
        return s;
    }

    fun provideBalanceValues() : IntArray{
        return values;
    }
    fun setBalanceTitle(input: String){
        balanceActivityBinding.balanceTitle.text = input;
    }
    fun setBalanceHelp(input: String){
        balanceActivityBinding.balanceHelp.text = input;
    }

    //animacio nem működik...
    fun revealView() {
        val x = balanceActivityBinding.balanceView.right;
        val y = balanceActivityBinding.balanceView.bottom;


        val startRadius = 0;
        val endRadius = hypot(
            balanceActivityBinding.balanceView.width.toDouble(),
            balanceActivityBinding.balanceView.height.toDouble()
        ).toInt();

        val anim = ViewAnimationUtils.createCircularReveal(
            balanceActivityBinding.balanceView,
            x,
            y,
            startRadius.toFloat(),
            endRadius.toFloat()
        )


        //hiba: java.lang.IllegalStateException: Cannot start this animator on a detached view!
        //else agra fut

        if (balanceActivityBinding.balanceView.isAttachedToWindow) {

            anim.setDuration(3).start();

        } else {
            Toast.makeText(this, "no Attach", Toast.LENGTH_LONG).show();
            balanceActivityBinding.balanceView.addOnAttachStateChangeListener(object : OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {
                    v.removeOnAttachStateChangeListener(this)

                    anim.setDuration(3).start();
                }

                override fun onViewDetachedFromWindow(v: View?) {}
            })


        }
    }
}